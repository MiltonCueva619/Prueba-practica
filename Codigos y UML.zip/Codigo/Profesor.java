
package com.mycompany.pruebapractica;

public class Profesor extends Persona {
    private double salario;
    
    public Profesor(String nombre, String numeroTelefono, String correoElectronico){
        super(nombre, numeroTelefono, correoElectronico);
    }
    
    public double getSalario(){
        return salario;
    }
    public void setSalario(double salario){
        this.salario = salario;
    }
    @Override
    public void comprarPaseEstacionamiento(){
        System.out.println("El profesor "+nombre+" ha comprado un pase de estacionamiento y la factura se envio al correo "+correoElectronico);  
    }
    
    public void darClase(String asignatura){
        System.out.println("El profesor "+nombre+" esta dictando clases de "+asignatura);
    }

   
}
