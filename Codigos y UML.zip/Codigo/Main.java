
package com.mycompany.pruebapractica;

public class Main {
    public static void main(String []args){
        Estudiante ingenieria = new Estudiante("Milton Cueva", "0985062653", "macueva14@espe.edu.ec", 19.5);
        ingenieria.setNumeroEstudiante("1546564");
        
        Profesor ingeniero = new Profesor("Adrian Cedeño","098854125", "adrianc@espe.edu.ec");
        ingeniero.setSalario(2254.75);
        
        ingenieria.comprarPaseEstacionamiento();
        ingenieria.estudiar("Programacion");
        ingenieria.estudiar("Programacion", 4);
        
        ingeniero.comprarPaseEstacionamiento();
        ingeniero.darClase("algebra lineal");
     
        
    }
    
}
