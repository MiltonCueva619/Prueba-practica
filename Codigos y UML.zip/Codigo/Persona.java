
package com.mycompany.pruebapractica;

public abstract class Persona {
    String nombre;
    String numeroTelefono;
    String correoElectronico;
    
    public Persona (String nombre, String numeroTelefono, String correoElectronico){
        this.nombre = nombre;
        this.numeroTelefono = numeroTelefono;
        this.correoElectronico = correoElectronico;
    }
    
    public abstract void comprarPaseEstacionamiento();

}
