
package com.mycompany.pruebapractica;

public class Estudiante extends Persona {
    private String numeroEstudiante;
    public double notaMedia;
    
    public Estudiante (String nombre, String numeroTelefono, String correoElectronico, double notaMedia){
        super(nombre, numeroTelefono, correoElectronico);
        this.notaMedia = notaMedia;
    }
    
    public String getNumeroEstudiante(){
        return numeroEstudiante;
    }
    public void setNumeroEstudiante (String numeroEstudiante){
        this.numeroEstudiante = numeroEstudiante;
    }
    
    @Override
    public void comprarPaseEstacionamiento(){
        System.out.println("El estudiante "+nombre+" ha comprado un pase de estacionamiento la factura le llegara al correo "+correoElectronico);
    }
    
    public void estudiar(String asignatura){
        System.out.println("El estudiante "+nombre+" estudia "+asignatura);
    }
    public void estudiar(String asignatura, int horas){
        System.out.println("El estudiante "+nombre+" estudia "+asignatura+" por "+horas+" horas");
    }
    
}
